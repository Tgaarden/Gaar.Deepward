--[[
  DeepwardUI: Frame Style — X-Perl-inspired tweaks to the default unit frames.
  Step 1 (this pass):
    * Class-coloured health bars for player units (player/target/focus/pet/party); NPC target/focus keep
      Blizzard's reaction colour.
    * Bigger, outlined text with a PERCENT on every health AND power bar ("cur/max  NN%").

  Client-side only (law I). More X-Perl features (portraits, buffs, thresholds) can follow.
]]

local _G = _G

local function DB()
    if type(DeepwardUIDB) ~= "table" then DeepwardUIDB = {} end
    local d = DeepwardUIDB
    if d.frameClassColor == nil then d.frameClassColor = true end
    if d.frameBarText   == nil then d.frameBarText   = true end
    if d.frameFontSize  == nil then d.frameFontSize  = 12 end
    if d.framePortraits == nil then d.framePortraits = true end   -- square portrait with our own border
    if d.frameThreshold == nil then d.frameThreshold = true end   -- recolour health bar on low HP
    if d.frameStripBorders == nil then d.frameStripBorders = true end   -- hide Blizzard's ornate borders
    if d.frameBackdrop == nil then d.frameBackdrop = true end           -- black see-through backing panel
    return d
end

-- unit token -> its top-level Blizzard frame (for the backdrop panel)
local FRAME_OF = {
    player = "PlayerFrame", target = "TargetFrame", focus = "FocusFrame", pet = "PetFrame",
    party1 = "PartyMemberFrame1", party2 = "PartyMemberFrame2", party3 = "PartyMemberFrame3", party4 = "PartyMemberFrame4",
}
-- Black, semi-transparent backing panel behind a unit frame's portrait + bars + name.
local function StyleBackdrop(f)
    local uf, pt, hb, mb = _G[FRAME_OF[f.u]], _G[f.p], _G[f.h], _G[f.m]
    if not (uf and pt and hb and mb) then return end
    if not f._bd then
        local bd = CreateFrame("Frame", nil, uf)
        bd:SetFrameLevel(math.max(0, uf:GetFrameLevel() - 1))   -- behind the bars/portrait
        bd:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 10,
            insets = { left = 2, right = 2, top = 2, bottom = 2 } })
        bd:SetBackdropColor(0, 0, 0, 0.5)          -- see-through black
        bd:SetBackdropBorderColor(0, 0, 0, 0.9)
        f._bd = bd
    end
    local bd = f._bd
    if not DB().frameBackdrop then bd:Hide(); return end
    bd:ClearAllPoints()
    bd:SetPoint("TOPLEFT", pt, "TOPLEFT", -4, 16)          -- include the name row above the portrait
    bd:SetPoint("BOTTOMRIGHT", mb, "BOTTOMRIGHT", 6, -4)   -- down to the bottom bar, out to the bar's right
    bd:Show()
end

-- Blizzard's ornate frame border textures (the gold rings incl. the round portrait ring). Hidden so our
-- own clean black-edged look shows. They get re-shown by Blizzard on updates, so this is re-applied.
local BLIZZ_BORDERS = {
    "PlayerFrameTexture", "TargetFrameTextureFrameTexture", "FocusFrameTextureFrameTexture", "PetFrameTexture",
    "PartyMemberFrame1Texture", "PartyMemberFrame2Texture", "PartyMemberFrame3Texture", "PartyMemberFrame4Texture",
}
local function StripBlizzardBorders()
    local hide = DB().frameStripBorders
    for _, n in ipairs(BLIZZ_BORDERS) do
        local t = _G[n]
        if t then
            if hide and t:IsShown() then t:Hide()
            elseif not hide and not t:IsShown() then t:Show() end
        end
    end
end

-- health bar, power bar, unit token, portrait texture
local FRAMES = {
    { h = "PlayerFrameHealthBar",       m = "PlayerFrameManaBar",       u = "player", p = "PlayerPortrait" },
    { h = "TargetFrameHealthBar",       m = "TargetFrameManaBar",       u = "target", p = "TargetPortrait" },
    { h = "FocusFrameHealthBar",        m = "FocusFrameManaBar",        u = "focus",  p = "FocusPortrait" },
    { h = "PetFrameHealthBar",          m = "PetFrameManaBar",          u = "pet",    p = "PetPortrait" },
    { h = "PartyMemberFrame1HealthBar", m = "PartyMemberFrame1ManaBar", u = "party1", p = "PartyMemberFrame1Portrait" },
    { h = "PartyMemberFrame2HealthBar", m = "PartyMemberFrame2ManaBar", u = "party2", p = "PartyMemberFrame2Portrait" },
    { h = "PartyMemberFrame3HealthBar", m = "PartyMemberFrame3ManaBar", u = "party3", p = "PartyMemberFrame3Portrait" },
    { h = "PartyMemberFrame4HealthBar", m = "PartyMemberFrame4ManaBar", u = "party4", p = "PartyMemberFrame4Portrait" },
}

-- Threshold-aware health colour: low HP overrides class colour (orange < 35%, red < 20%).
local function ApplyHealthColor(bar, unit)
    if not bar or not bar.SetStatusBarColor then return end
    if not DB().frameClassColor or not unit or not UnitExists(unit) or not UnitIsPlayer(unit) then return end
    local hp, hpm = UnitHealth(unit), UnitHealthMax(unit)
    local pct = (hpm and hpm > 0) and (hp / hpm) or 1
    if DB().frameThreshold and pct <= 0.20 then bar:SetStatusBarColor(0.95, 0.12, 0.12)
    elseif DB().frameThreshold and pct <= 0.35 then bar:SetStatusBarColor(1.0, 0.55, 0.0)
    else
        local _, cls = UnitClass(unit)
        local c = cls and RAID_CLASS_COLORS and RAID_CLASS_COLORS[cls]
        if c then bar:SetStatusBarColor(c.r, c.g, c.b) end
    end
end

-- Class-coloured border ring around a portrait (X-Perl look). Created once, cached on the portrait.
local function PortraitBorder(portraitName, unit)
    local pt = _G[portraitName]
    if not pt then return end
    if not pt._dwBorder then
        local b = CreateFrame("Frame", nil, pt:GetParent())
        b:SetFrameLevel((pt:GetParent():GetFrameLevel() or 0) + 1)
        b:SetPoint("TOPLEFT", pt, "TOPLEFT", -3, 3)
        b:SetPoint("BOTTOMRIGHT", pt, "BOTTOMRIGHT", 3, -3)
        b:SetBackdrop({ edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12 })
        pt._dwBorder = b
    end
    local b = pt._dwBorder
    if not DB().framePortraits or not UnitExists(unit) then
        b:Hide()
        if pt.SetTexCoord then pt:SetTexCoord(0, 1, 0, 1) end
        return
    end
    -- Square the portrait: crop the round edges so it fills the square border instead of looking round.
    if pt.SetTexCoord then pt:SetTexCoord(0.16, 0.86, 0.16, 0.86) end
    b:SetBackdropBorderColor(0, 0, 0, 1)   -- our own clean black edge (Blizzard's round ring is hidden)
    b:Show()
end

-- Party frames have very thin health/mana bars — the two lines of text overlap and can't be read. Give the
-- party bars more height and stack mana cleanly under health. Re-applied from the driver since Blizzard
-- relays the party frames on updates.
-- Square portrait sized to the FULL bar block (top of the health bar to the bottom of the last bar),
-- placed just left of the bars. Measured with GetTop/GetBottom so it matches however many bars are shown.
local function StyleBigPortrait(portraitName, hbName, mbName)
    local pt, hb, mb = _G[portraitName], _G[hbName], _G[mbName]
    if not (pt and hb and mb) then return end
    if not DB().framePortraits then return end
    local top, bot = hb:GetTop(), mb:GetBottom()
    if not top or not bot then return end
    local h = top - bot          -- full height spanned by the bars
    if h < 8 then return end
    pt:ClearAllPoints()
    pt:SetPoint("TOPRIGHT", hb, "TOPLEFT", -5, 0)
    pt:SetHeight(h)
    pt:SetWidth(h)               -- square
    if pt.SetTexCoord then pt:SetTexCoord(0.16, 0.86, 0.16, 0.86) end
end

local PARTY_HB_W, PARTY_HB_H, PARTY_MB_H = 112, 16, 11
local function StylePartyBars(idx)
    local hb = _G["PartyMemberFrame" .. idx .. "HealthBar"]
    local mb = _G["PartyMemberFrame" .. idx .. "ManaBar"]
    local nm = _G["PartyMemberFrame" .. idx .. "Name"]
    if not hb or not mb then return end
    -- health bar: wide + tall, anchored under the name (fixed so Blizzard's relayout can't shrink it)
    if nm then
        hb:ClearAllPoints()
        hb:SetPoint("TOPLEFT", nm, "BOTTOMLEFT", 0, -2)
    end
    hb:SetWidth(PARTY_HB_W); hb:SetHeight(PARTY_HB_H)
    -- mana bar: same width, stacked right under health
    mb:ClearAllPoints()
    mb:SetPoint("TOPLEFT", hb, "BOTTOMLEFT", 0, -2)
    mb:SetWidth(PARTY_HB_W); mb:SetHeight(PARTY_MB_H)
end

local function Short(n)
    n = n or 0
    if n >= 1e6 then return ("%.1fM"):format(n / 1e6) end
    if n >= 1e3 then return ("%.1fk"):format(n / 1e3) end
    return tostring(n)
end

-- Overlay a bigger, outlined fontstring on a status bar (created once, cached on the bar).
local function BarText(bar)
    if not bar then return nil end
    if not bar._dwText then
        local fs = bar:CreateFontString(nil, "OVERLAY")
        fs:SetFont(STANDARD_TEXT_FONT, DB().frameFontSize, "OUTLINE")
        fs:SetPoint("CENTER", bar, "CENTER", 0, 0)
        fs:SetTextColor(1, 1, 1)
        bar._dwText = fs
        -- dim Blizzard's own bar text so it doesn't double up with ours
        if bar.TextString then bar.TextString:SetAlpha(0) end
    end
    return bar._dwText
end

local function UpdateBarText(barName, unit, powerBar)
    local bar = _G[barName]
    if not bar then return end
    local fs = BarText(bar)
    if not fs then return end
    if not DB().frameBarText or not UnitExists(unit) then fs:SetText(""); return end
    local cur, max
    if powerBar then cur, max = UnitPower(unit), UnitPowerMax(unit)
    else cur, max = UnitHealth(unit), UnitHealthMax(unit) end
    if not max or max <= 0 then fs:SetText(""); return end
    local pct = math.floor(cur / max * 100 + 0.5)
    fs:SetText(("%s/%s  %d%%"):format(Short(cur), Short(max), pct))
end

-- Class-colour (+ low-HP threshold) health bars for player units, after every Blizzard health update.
if type(UnitFrameHealthBar_Update) == "function" then
    hooksecurefunc("UnitFrameHealthBar_Update", function(bar, unit)
        ApplyHealthColor(bar, unit)
    end)
end

-- Live updater (0.2s): bar text, threshold re-colour, portrait borders.
local driver = CreateFrame("Frame")
local acc = 0
driver:SetScript("OnUpdate", function(_, e)
    acc = acc + e
    if acc < 0.2 then return end
    acc = 0
    for _, f in ipairs(FRAMES) do
        UpdateBarText(f.h, f.u, false)
        UpdateBarText(f.m, f.u, true)
        ApplyHealthColor(_G[f.h], f.u)
        PortraitBorder(f.p, f.u)
        StyleBackdrop(f)
    end
    for i = 1, 4 do StylePartyBars(i) end   -- keep party bars tall + readable
    StyleBigPortrait("PlayerPortrait", "PlayerFrameHealthBar", "PlayerFrameManaBar")
    StyleBigPortrait("TargetPortrait", "TargetFrameHealthBar", "TargetFrameManaBar")
    StripBlizzardBorders()
end)

-- Re-assert class colour when the target/focus/party changes (Blizzard repaints these).
local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_TARGET_CHANGED")
ev:RegisterEvent("PLAYER_FOCUS_CHANGED")
ev:RegisterEvent("PARTY_MEMBERS_CHANGED")
ev:RegisterEvent("UNIT_PET")
ev:SetScript("OnEvent", function()
    if type(UnitFrameHealthBar_Update) ~= "function" then return end
    for _, f in ipairs(FRAMES) do
        local bar = _G[f.h]
        if bar and UnitExists(f.u) then UnitFrameHealthBar_Update(bar, f.u) end
    end
end)

local function SetFontSize(s)
    DB().frameFontSize = s
    for _, f in ipairs(FRAMES) do
        for _, bn in ipairs({ f.h, f.m }) do
            local bar = _G[bn]
            if bar and bar._dwText then bar._dwText:SetFont(STANDARD_TEXT_FONT, s, "OUTLINE") end
        end
    end
end

-- ---------------------------------------------------------------------------
-- Unified Unit-Frames config menu (opened by /dwframes menu, /dwstyle, or the Deepward panel button).
-- ---------------------------------------------------------------------------
local menuFrame = CreateFrame("Frame", "DeepwardFramesMenu", UIParent, "UIDropDownMenuTemplate")
local function ConfigMenu()
    local locked = DeepwardUIDB and DeepwardUIDB.framesLocked
    return {
        { text = "Unit Frames", isTitle = true, notCheckable = true },
        { text = "Class-coloured bars", checked = DB().frameClassColor, keepShownOnClick = true,
          func = function() DB().frameClassColor = not DB().frameClassColor end },
        { text = "Bar text (percent)", checked = DB().frameBarText, keepShownOnClick = true,
          func = function() DB().frameBarText = not DB().frameBarText end },
        { text = "Class portraits", checked = DB().framePortraits, keepShownOnClick = true,
          func = function() DB().framePortraits = not DB().framePortraits end },
        { text = "Low-HP colour (orange/red)", checked = DB().frameThreshold, keepShownOnClick = true,
          func = function() DB().frameThreshold = not DB().frameThreshold end },
        { text = "Hide Blizzard borders (black edge)", checked = DB().frameStripBorders, keepShownOnClick = true,
          func = function() DB().frameStripBorders = not DB().frameStripBorders; StripBlizzardBorders() end },
        { text = "Black backing panel", checked = DB().frameBackdrop, keepShownOnClick = true,
          func = function() DB().frameBackdrop = not DB().frameBackdrop end },
        { text = "Font size", notCheckable = true, hasArrow = true, menuList = {
            { text = "Small (11)",  checked = (DB().frameFontSize == 11), func = function() SetFontSize(11) end },
            { text = "Normal (12)", checked = (DB().frameFontSize == 12), func = function() SetFontSize(12) end },
            { text = "Large (14)",  checked = (DB().frameFontSize == 14), func = function() SetFontSize(14) end },
            { text = "Huge (16)",   checked = (DB().frameFontSize == 16), func = function() SetFontSize(16) end },
        } },
        { text = "Frame scale", notCheckable = true, hasArrow = true, menuList = {
            { text = "90%",  checked = (DeepwardUIDB and DeepwardUIDB.frameScale == 0.9),  func = function() DeepwardUIDB.frameScale = 0.9;  if DeepwardFrames_ApplyScale then DeepwardFrames_ApplyScale() end end },
            { text = "100%", checked = (DeepwardUIDB and (DeepwardUIDB.frameScale or 1) == 1), func = function() DeepwardUIDB.frameScale = 1.0;  if DeepwardFrames_ApplyScale then DeepwardFrames_ApplyScale() end end },
            { text = "110%", checked = (DeepwardUIDB and DeepwardUIDB.frameScale == 1.1),  func = function() DeepwardUIDB.frameScale = 1.1;  if DeepwardFrames_ApplyScale then DeepwardFrames_ApplyScale() end end },
            { text = "125%", checked = (DeepwardUIDB and DeepwardUIDB.frameScale == 1.25), func = function() DeepwardUIDB.frameScale = 1.25; if DeepwardFrames_ApplyScale then DeepwardFrames_ApplyScale() end end },
        } },
        { text = (locked and "Unlock moving (shift-drag)" or "Lock moving"), notCheckable = true,
          func = function() if DeepwardFrames_ToggleLock then DeepwardFrames_ToggleLock() end end },
        { text = "Reset positions (then /reload)", notCheckable = true,
          func = function() if DeepwardFrames_ResetPositions then DeepwardFrames_ResetPositions() end end },
        { text = "Close", notCheckable = true, func = function() end },
    }
end

function DeepwardFrames_Config()
    EasyMenu(ConfigMenu(), menuFrame, "cursor", 0, 0, "MENU")
end
_G.DeepwardFrames_Config = DeepwardFrames_Config

SLASH_DEEPWARDFRAMESTYLE1 = "/dwstyle"
SlashCmdList["DEEPWARDFRAMESTYLE"] = function() DeepwardFrames_Config() end
